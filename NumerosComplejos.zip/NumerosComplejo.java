import java.util.Objects;

public class NumerosComplejo {

	private double parteReal;
	private double parteImaginaria;
	public NumerosComplejo(double parteReal, double parteImaginaria) {
		super();
		this.parteReal = parteReal;
		this.parteImaginaria = parteImaginaria;
	}

	public double getParteReal() {
		return parteReal;
	}

	public void setParteReal(double parteReal) {
		this.parteReal = parteReal;
	}

	public double getParteImaginaria() {
		return parteImaginaria;
	}

	public void setParteImaginaria(double parteImaginaria) {
		this.parteImaginaria = parteImaginaria;
	}
	public String sumaComplejos(NumerosComplejo numero2) {
		double resultadoParteReal;
		double resultadoParteImaginaria;
		resultadoParteReal=this.parteReal+numero2.getParteReal();
		resultadoParteImaginaria=this.parteImaginaria+numero2.getParteImaginaria();
		return "El numero es "+ resultadoParteReal+"+"+resultadoParteImaginaria+"i";
	}

	public String restaComplejos(NumerosComplejo numero2) {
		double resultadoParteReal;
		double resultadoParteImaginaria;
		resultadoParteReal=this.parteReal-numero2.getParteReal();
		resultadoParteImaginaria=this.parteImaginaria-numero2.getParteImaginaria();
		return "El numero es "+ resultadoParteReal+"+"+resultadoParteImaginaria+"i";
	}

	@Override
	public String toString() {
		return "Complejo [parteReal=" + parteReal + ", parteImaginaria=" + parteImaginaria +"i" + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(parteImaginaria, parteReal);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NumerosComplejo other = (NumerosComplejo) obj;
		return Double.doubleToLongBits(parteImaginaria) == Double.doubleToLongBits(other.parteImaginaria)
				&& Double.doubleToLongBits(parteReal) == Double.doubleToLongBits(other.parteReal);
	}

}
